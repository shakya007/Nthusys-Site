$('.banner-main').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplay: true,
  autoplaySpeed: 2000,
});


$('.slider').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplay: true,
  dots: true,
  autoplaySpeed: 2000,
});



// $(document).ready(function () {
//   $(".hamburger-menu").click(function () {
//     $("body").toggleClass('mobile-menu')
//   })
// })
